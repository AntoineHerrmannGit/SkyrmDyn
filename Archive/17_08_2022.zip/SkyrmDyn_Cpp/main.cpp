#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>

#include <typeinfo>

#include <filesystem>

#include <ctime>
#include <random>
#include <chrono>

#include <cmath>

#include "File_management/file_management.h"

#include "Inputs/Readers/inputs_reader.h"

#include "Maths/Random/random.h"
#include "Maths/Objects/Matrix/Real_matrix/real_matrix.h"

#include "Maths/Functions/distribution_functions.h"
#include "Maths/Objects/Tensor/Vector_tensor/vector_tensors.h"

#include "Maths/Operators/vector_operators.h"

#include "Objects/Lattice/lattice.h"
#include "Objects/Parameter/parameter.h"
#include "Objects/System_config/system_config.h"

#include "Plotting/setup_povray_file.h"


int main( /* int argc, char *argv[] */ )
{

    setup_povray_file();
    /*
    clear_output_directories();
    Lattice lattice;
    while( lattice.get_parameter().get_current_time() < lattice.get_parameter().get_llg_time() ) {
        lattice.euler_llg_evolution();
        std::cout<<"Step " + std::to_string( lattice.get_parameter().get_current_llg_step() ) + " / " + std::to_string( (int) ( lattice.get_parameter().get_llg_time() / lattice.get_parameter().get_llg_time_step() ) ) + "\n";
    }

    System_config syst;
    //syst.make_all_images();

    System_config syst;
    syst.plot_figures();
    */

    std::cout << "Well done \n";

    return 0;
}
