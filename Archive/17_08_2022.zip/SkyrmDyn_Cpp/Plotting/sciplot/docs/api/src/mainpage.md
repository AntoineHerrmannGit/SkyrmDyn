# sciplot's API Reference {#mainpage}

Welcome to %sciplot's C++ API reference.

Here are a few important classes in %sciplot that you might want to read about.

- @ref sciplot::Plot
- @ref sciplot::Figure

Check the namespace sciplot for all available classes and methods.
