#pragma once

void plot();
