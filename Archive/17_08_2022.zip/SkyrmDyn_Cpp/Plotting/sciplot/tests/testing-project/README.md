# Testing Project

This project here exists for testing that sciplot does not produce linking errors
resulting for missing `inline` specifiers in some method definitions.
