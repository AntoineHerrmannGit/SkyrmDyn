#ifndef MAKE_IMAGES_H
#define MAKE_IMAGES_H

#include "Objects/System_config/system_config.h"

void System_config::make_single_image();
void System_config::make_all_images();

#endif // MAKE_IMAGES_H
