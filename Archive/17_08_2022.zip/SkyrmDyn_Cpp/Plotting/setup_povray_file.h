#ifndef SETUP_POVRAY_FILE_H
#define SETUP_POVRAY_FILE_H

void setup_povray_file();

void set_camera();

void set_light_source();

#endif // SETUP_POVRAY_FILE_H
