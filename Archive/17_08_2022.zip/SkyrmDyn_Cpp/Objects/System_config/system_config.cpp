#include "system_config.h"

#include "Plotting/setup_povray_file.h"

#include "Inputs/Readers/system_reader.h"

// Constructor
//-----------------------------------
System_config::System_config()
{
    initialize();
}

// Getters
//-----------------------------------
std::string System_config::get_system() {
    return system;
}

std::string System_config::get_python() {
    return python;
}
std::string System_config::get_povray() {
    return povray;
}

std::string System_config::get_code() {
    return code;
}

void System_config::plot_figures() {
    //make_all_images();
    make_graphs();
    make_animations();
}

// Private library
//-----------------------------------
void System_config::initialize() {
    system = get_system_string( std::string( "system" ) );
    python = get_system_string( std::string( "python" ) );
    povray = get_system_string( std::string( "povray" ) );
    code = get_system_string( std::string( "code" ) );
    setup_povray_file();
}
