#ifndef SYSTEM_READER_H
#define SYSTEM_READER_H

#include <string>

std::string get_system_as_string( std::string& parameter_to_find );

std::string get_system_string( std::string name );

#endif // SYSTEM_READER_H
