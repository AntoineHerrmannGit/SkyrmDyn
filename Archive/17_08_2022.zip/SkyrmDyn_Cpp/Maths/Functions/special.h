#ifndef SPECIAL_H
#define SPECIAL_H

int factorial( int n );
double SinInt( double x );

#endif // SPECIAL_H
