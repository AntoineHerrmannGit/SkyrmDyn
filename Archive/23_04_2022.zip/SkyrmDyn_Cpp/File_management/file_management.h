#ifndef FILE_MANAGEMENT_H
#define FILE_MANAGEMENT_H

#include <string>

void clear_directory( std::string directory );

#endif // FILE_MANAGEMENT_H
