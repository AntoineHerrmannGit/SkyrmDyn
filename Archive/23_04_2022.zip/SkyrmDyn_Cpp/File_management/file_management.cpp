#include "File_management/file_management.h"

#include <string>
#include <filesystem>

void clear_directory( std::string directory ) {
    std::string path = "./Outputs/" + directory + "/";
    for (auto& file : std::filesystem::directory_iterator( path )) {
            std::filesystem::remove_all( file );
    }
}




