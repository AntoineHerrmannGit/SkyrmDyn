#include "atom.h"

#include "Maths/Objects/Array/Array_double/array_double.h"

#include "Maths/Operators/vector_operators.h"

#include <iostream>
#include <iomanip>
#include <math.h>
#include <fstream>

// Constructor
//-----------------------------------
Atom::Atom( Array_double &new_position, Array_double &new_spin ) {
    position.set_array( new_position );
    spin.set_array( new_spin );
};
Atom::Atom() {

}

// Getters
//-----------------------------------
Array_double Atom::get_position() {
    return position;
};

Array_double Atom::get_spin() {
    return spin;
};

std::vector< Atom > Atom::get_nearest_neighbors() {
    return nearest_neighbors;
}


// Setters
//-----------------------------------
void Atom::set_position( const Array_double &new_position ) {
    position = new_position;
};

void Atom::set_spin( const Array_double &new_spin ) {
    spin = new_spin;
};

void Atom::set_nearest_neighbors( std::vector< Atom > list_of_nearest_neighbors ) {
    nearest_neighbors = list_of_nearest_neighbors;
};

// Public libraries
//-----------------------------------
bool Atom::operator==( Atom& rhs ) {
    if( ( rhs.get_position() == position ) && ( rhs.get_spin() == spin ) ) {
        return true;
    }
    else {
        return false;
    }
}
bool Atom::operator!=( Atom& rhs ) {
    if( ( rhs.get_position() != position ) || ( rhs.get_spin() != spin ) ) {
        return true;
    }
    else {
        return false;
    }
}


// Private Libraries
//-----------------------------------








