#ifndef ATOM_H
#define ATOM_H

#include "Maths/Objects/Array/Array_double/array_double.h"

#include <string>
#include <vector>

class Atom
{
public:
    // Constructor
    //-----------------------------------
    Atom( Array_double &new_position, Array_double &new_spin );
    Atom();

    // Getters
    //-----------------------------------
    Array_double get_position();
    Array_double get_spin();

    std::vector< Atom > get_nearest_neighbors();

    // Setters
    //-----------------------------------
    void set_position( const Array_double &new_position );
    void set_spin( const Array_double &new_spin );

    void set_nearest_neighbors( std::vector< Atom > list_of_nearest_neighbors );

    // Public libraries
    //-----------------------------------
    bool operator==( Atom& rhs );
    bool operator!=( Atom& rhs );

    double distance( Atom& other );

    Array_double relative_position( Atom& other );

    void write_spin( int step );

private:
    Array_double position;
    Array_double spin;

    std::vector< Atom > nearest_neighbors;
};

#endif // ATOM_H
