#include "cell.h"

#include "Objects/Atom/atom.h"

#include "Maths/Objects/Array/Array_int/array_int.h"
#include "Maths/Objects/Array/Array_double/array_double.h"

#include <vector>
#include <math.h>


// Constructor
//-----------------------------------
Cell::Cell( std::string &lat_name, Array_int &new_position )
{
    label = new_position;
    name = lat_name;
    setup_cell( lat_name );
    setup_position( lat_name, new_position );
};
Cell::Cell() {

}

// Getters
//-----------------------------------
std::vector< Atom > Cell::get_cell() {
    return cell;
}

std::string Cell::get_name() {
    return name;
}

Array_double Cell::get_position() {
    return position;
}

Array_int Cell::get_label() {
    return label;
}

Atom Cell::get_atom( int n ) {
    return cell[n];
};

int Cell::get_nb_atoms() {
    return nb_atoms;
}

// Public libraries
//-----------------------------------
bool Cell::check_atom_in_cell( Atom& atom ) {
    for( Atom atoms : cell ) {
        if( atom == atoms ) {
            return true;
        }
    }
    return false;
}

bool Cell::operator==( Cell& cellular ) {
    if( ( cellular.get_position() == position ) &&
        ( cellular.get_label() == label ) &&
        ( cellular.get_name() == name ) &&
        ( cellular.get_nb_atoms() == nb_atoms ) ){
        int i=0;
        for( Atom atom : cellular.get_cell() ) {
            if( atom != cell[i] ) {
                return false;
            }
            else {
                i++;
            }
        }
        return true;
    }
    else {
        return false;
    }
}
bool Cell::operator!=( Cell& cellular ) {
    if( ( cellular.get_position() != position ) ||
        ( cellular.get_label() != label ) ||
        ( cellular.get_name() != name ) ||
        ( cellular.get_nb_atoms() != nb_atoms ) ){
        return true;
    }
    else {
        int i=0;
        for( Atom atom : cellular.get_cell() ) {
            if( atom != cell[i] ) {
                return true;
            }
            else {
                i++;
            }
        }
        return false;
    }
}



// Private library
//-----------------------------------
