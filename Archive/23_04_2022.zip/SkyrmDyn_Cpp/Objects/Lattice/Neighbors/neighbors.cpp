#include "Objects/Lattice/lattice.h"


void Lattice::neighbors_list( Atom& atom, int neighbor_rank, std::vector< std::vector<Atom> > neighbors ) {
    std::vector<Atom> tmp_vector;
    tmp_vector.push_back( atom );
    neighbors.push_back( tmp_vector );

    // For all ranks, fill the list rank by rank
    for( int i=0; i< neighbor_rank; i++ ) {
        // Find the nearest neighbors of the atoms of the further rank
        std::vector< Atom > tmp_neighbors;
        for( Atom atoms : neighbors[i] ) {
            std::vector< Atom > tmp_list;
            nearest_neighbors( atom, tmp_list );
            for( Atom tmp_atom : tmp_list ) {
                tmp_neighbors.push_back( tmp_atom );
            }
        }

        // Check if the atoms are not already taken
        for( int j=0; j<(int)neighbors.size(); j++ ) {
            for( Atom tmp_atom : neighbors[j] ) {
                int n=0;
                for( Atom candidate : tmp_neighbors ) {
                    if( tmp_atom == candidate ) {
                        tmp_neighbors.erase(tmp_neighbors.begin()+n);
                    }
                    n++;
                }
            }
        }
        neighbors.push_back( tmp_neighbors );
    }
}

void Lattice::find_neighboring_cells( Cell& cell, std::vector<Cell> &neighboring_cells ) {
    Array_int cell_label = cell.get_label();
    for( Cell cells : lattice ) {
        Array_int cells_label = cells.get_label();
        if( ( ( cells_label.get_x() == cell_label.get_x()+1 ) ||
              ( cells_label.get_x() == cell_label.get_x()-1 ) ) &&
            ( ( cells_label.get_y() == cell_label.get_y()+1 ) ||
              ( cells_label.get_y() == cell_label.get_y()-1 ) ) &&
            ( ( cells_label.get_z() == cell_label.get_z()+1 ) ||
              ( cells_label.get_z() == cell_label.get_z()-1 ) ) ) {
            neighboring_cells.push_back( cells );
        }
    }
}

void Lattice::nearest_neighbors( Atom& atom, std::vector<Atom> neighbors_list ) {
    Cell cell = find_cell( atom );
    std::vector<Cell> neighboring_cells;
    find_neighboring_cells( cell, neighboring_cells );
    double dist = parameters.get_lattice_step();
    for( Cell cells : neighboring_cells ) {
        for( Atom atoms : cells.get_cell() ) {
            if( atom.distance( atoms ) <= dist ) {
                neighbors_list.push_back( atoms );
            }
        }
    }
}



void Lattice::attribute_neighbors() {
    std::vector<Atom> neighbors_list;
    for( Cell cells : lattice ) {
        for( Atom atoms : cells.get_cell() ) {
            nearest_neighbors( atoms, neighbors_list );
            atoms.set_nearest_neighbors( neighbors_list );
        }
    }
}





