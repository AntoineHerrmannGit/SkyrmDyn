#ifndef LATTICE_H
#define LATTICE_H

#include "Objects/Atom/atom.h"
#include "Objects/Cell/cell.h"
#include "Objects/Parameter/parameter.h"

#include "Maths/Objects/Array/Array_int/array_int.h"

#include <vector>
#include <string>

class Lattice
{
public:
    // Constructor
    //-----------------------------------
    Lattice();

    // Getters
    //-----------------------------------
    std::vector< Cell > get_lattice();
    Cell get_cell( int &x, int &y, int &z );
    int get_dimension();
    Parameter get_parameter();

    // Public libraries
    //-----------------------------------
    Cell find_cell( Atom& atom );
    void neighbors_list( Atom& atom, int neighbor_rank, std::vector< std::vector<Atom> > neighbors );
    void find_neighboring_cells( Cell& cell, std::vector<Cell> &neighboring_cells );
    void nearest_neighbors( Atom& atom, std::vector<Atom> neighbors_list );

    void write_atomic_positions();
    void write_atomic_spins( int step );
    void write_energy();
    void write_magnetization();
    void write_temperature();

    Array_double total_magnetization();

    double total_anisotropy_energy();
    double total_biquadratic_energy();
    double total_dipole_energy();
    double total_dmi_energy();
    double total_four_spins_energy();
    double total_heisenberg_energy();
    double total_zeeman_energy();

    double total_energy();

private:
    std::vector< Cell > lattice;
    Parameter parameters;

    void setup_lattice_configuration();
    void setup_initial_spin_config();

    void setup_ferromagnetic();
    void setup_ferrimagnetic();
    void setup_antiferromagnetic();
    void setup_spin_spiral();
    void setup_spin_skyrmion();
    void setup_random();

    void setup_skyrmion_charge_1();
    void setup_skyrmion_large_charge();

    void attribute_neighbors();
};

#endif // LATTICE_H
