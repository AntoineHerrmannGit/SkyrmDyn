#include "Objects/Lattice/lattice.h"

double Lattice::total_energy() {
    double tot_e = total_anisotropy_energy() +
                   total_biquadratic_energy() +
                   total_dipole_energy() +
                   total_dmi_energy() +
                   total_four_spins_energy() +
                   total_heisenberg_energy() +
                   total_zeeman_energy();
    return tot_e;
}
