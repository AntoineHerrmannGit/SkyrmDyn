#include "Objects/Lattice/lattice.h"

#include "Objects/Parameter/parameter.h"

#include "Maths/Objects/Array/Array_int/array_int.h"

#include <string.h>

void Lattice::setup_lattice_configuration() {
    Array_int lattice_size = parameters.get_lattice_size();
    std::string lattice_name = parameters.get_lattice_name();

    for( int i=0; i<lattice_size.get_component(0); i++ ) {
        for( int j=0; j<lattice_size.get_component(1); j++ ) {
            for( int k=0; k<lattice_size.get_component(2); k++ ) {
                Array_int position( 3 );
                position.set_component(0,i);
                position.set_component(1,j);
                position.set_component(2,k);

                Cell cell( lattice_name, position );
                lattice.push_back( cell );
            }
        }
    }
};
