#include "Objects/Lattice/lattice.h"

#include "Maths/Objects/Array/Array_double/array_double.h"

#include "Error_messages/error_messages.h"

#include <iomanip>
#include <iostream>
#include <fstream>
#include <string.h>


void Lattice::write_atomic_positions() {
    std::string filename = "./Outputs/Positions/position.dat";
    std::ofstream write( filename, std::ios::app );
    for( Cell cells : lattice ) {
        Array_double cell_position = cells.get_position();
        for( Atom atoms : cells.get_cell() ) {
            Array_double atomic_position = atoms.get_position();
            atomic_position.add( cell_position );
            for( int i=0; i<atomic_position.get_dimension(); i++ ) {
                write << std::setprecision(6)
                      << atomic_position.get_component( i ) << "   ";
            }
            write << " \n";
        }
    }
    write.close();
}

void Lattice::write_atomic_spins( int step ) {
    for( Cell cells : lattice ) {
        for( Atom atoms : cells.get_cell() ) {
            atoms.write_spin( step );
        }
    }
}

void Lattice::write_energy() {
    std::string filename = "./Outputs/Energy/energy.dat";
    std::ofstream write( filename, std::ios::app );
    if( write ) {

    }
    else {
        throw( DeclarationError( "write" ) );
    }
}

void Lattice::write_magnetization() {
    std::string filename = "./Outputs/Magnetization/magnetization.dat";
    std::ofstream write( filename, std::ios::app );
    if( write ) {

    }
    else {
        throw( DeclarationError( "write" ) );
    }
}

void Lattice::write_temperature() {
    std::string filename = "./Outputs/Temperature/temperature.dat";
    std::ofstream write( filename, std::ios::app );
    if( write ) {

    }
    else {
        throw( DeclarationError( "write" ) );
    }
}

