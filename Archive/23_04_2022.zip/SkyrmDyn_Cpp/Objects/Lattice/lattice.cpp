#include "lattice.h"

#include "Objects/Atom/atom.h"
#include "Objects/Cell/cell.h"
#include "Objects/Parameter/parameter.h"

#include "Maths/Objects/Array/Array_int/array_int.h"
#include "Maths/Objects/Array/Array_double/array_double.h"

#include "Maths/Operators/vector_operators.h"

#include "Error_messages/error_messages.h"

#include <vector>
#include <string>
#include <math.h>
#include <fstream>

// Constructor
//-----------------------------------
Lattice::Lattice() {
    setup_lattice_configuration();
    setup_initial_spin_config();
    write_atomic_positions();
    write_atomic_spins( 0 );
}



// Getters
//-----------------------------------
std::vector< Cell > Lattice::get_lattice() {
    return lattice;
};

Cell Lattice::get_cell( int &i, int &j, int &k ) {
    Array_int lattice_dimension = parameters.get_lattice_size();
    int p = lattice_dimension.get_x()*i + lattice_dimension.get_y()*j + lattice_dimension.get_z()*k;
    return lattice[p];
};

int Lattice::get_dimension() {
    std::string dim = parameters.get_lattice_name();
    dim = dim[0];
    int dimension = std::stoi( dim );
    return dimension;
}

Parameter Lattice::get_parameter() {
    return parameters;
}



// Public libraries
//-----------------------------------
Cell Lattice::find_cell( Atom& atom ) {
    for( Cell& cell : lattice ) {
        // find is not accepting the overloaded operator==
        if( cell.check_atom_in_cell( atom ) ) {
            return cell;
        }
    }
    throw( UnfoudVariableError( "cell" ) );
}


// Private library
//-----------------------------------




