#ifndef COMPLEX_MATRIX_H
#define COMPLEX_MATRIX_H

#include <vector>
#include <complex>

class Complex_matrix
{
public:
    // Constructor
    //-----------------------------------
    Complex_matrix( int dimension );

    // Gettters
    //-----------------------------------
    std::vector< std::vector< std::complex< double > > > get_matrix();
    std::complex< double > get_matrix_component( int &i, int &j );

    // Settters
    //-----------------------------------
    void set_matrix_component( int i, int j, std::complex< double > &element );

private:
    std::vector< std::vector< std::complex< double > > > matrix;

    void transpose();
    void hermitian_conjugate();
};

#endif // COMPLEX_MATRIX_H
