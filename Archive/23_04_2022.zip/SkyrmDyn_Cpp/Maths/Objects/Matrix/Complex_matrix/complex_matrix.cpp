#include "complex_matrix.h"

#include <vector>
#include <complex>

// Constructor
//-----------------------------------
Complex_matrix::Complex_matrix( int dimension )
{
    std::vector< std::vector< std::complex< double > > > tmp;
    for( int i=0; i<dimension; i++ ) {
        std::vector< std::complex< double > > tmp2;
        for( int j=0; j<dimension; j++ ) {
            tmp2.push_back(0);
        }
        tmp.push_back(tmp2);
    }
    matrix = tmp;
};

// Gettters
//-----------------------------------
std::vector< std::vector< std::complex< double > > > Complex_matrix::get_matrix() {
    return matrix;
}

std::complex< double > Complex_matrix::get_matrix_component( int &i, int &j ) {
    return matrix[i][j];
}

// Settters
//-----------------------------------
void Complex_matrix::set_matrix_component( int i, int j, std::complex< double > &element ) {
    matrix[i][j] = element;
}

// Private Library
//-----------------------------------
void Complex_matrix::transpose() {
    std::vector< std::vector< std::complex< double > > > tmp = matrix;
    int dim = sizeof(matrix)/sizeof(matrix[0]);
    for( int i=0; i<dim; i++ ) {
        for( int j=0; j<dim; j++ ) {
            matrix[i][j] = tmp[j][i];
        }
    }
}

void Complex_matrix::hermitian_conjugate() {
    std::vector< std::vector< std::complex< double > > > tmp = matrix;
    int dim = sizeof(matrix)/sizeof(matrix[0]);
    for( int i=0; i<dim; i++ ) {
        for( int j=0; j<dim; j++ ) {
            matrix[i][j] = std::conj( tmp[j][i] );
        }
    }
}
