#include "real_matrix.h"

#include "Maths/Objects/Array/Array_double/array_double.h"

#include <vector>

// Constructor
//-----------------------------------
Real_matrix::Real_matrix( int new_dimension )
{
    std::vector< std::vector< double > > tmp;
    for( int i=0; i<new_dimension; i++ ) {
        std::vector< double > tmp2;
        for( int j=0; j<new_dimension; j++ ) {
            tmp2.push_back(0);
        }
        tmp.push_back(tmp2);
    }
    matrix = tmp;
    dimension = new_dimension;
};

// Gettters
//-----------------------------------
std::vector< std::vector< double > > Real_matrix::get_matrix() {
    return matrix;
}
double Real_matrix::get_component( int i, int j ) {
    return matrix[i][j];
}
int Real_matrix::get_dimension() {
    return dimension;
}

// Settters
//-----------------------------------
void Real_matrix::set_component( int i, int j, double &element ) {
    matrix[i][j] = element;
}

// Public library
//-----------------------------------
void Real_matrix::transpose() {
    std::vector< std::vector< double > > tmp = matrix;
    int dim = sizeof(matrix)/sizeof(matrix[0]);
    for( int i=0; i<dim; i++ ) {
        for( int j=0; j<dim; j++ ) {
            matrix[i][j] = tmp[j][i];
        }
    }
}

double Real_matrix::determinant() {
    double det;
    if( dimension == 1 ) {
        det = get_component(0,0);
    }
    else if( dimension == 2 ) {
        det = get_component(0,0)*get_component(1,1) -                get_component(0,1)*get_component(1,0);
    }
    else if( dimension == 3 ) {
        det = get_component(0,0)*get_component(1,1)*get_component(2,2)
                   + get_component(1,0)*get_component(2,1)*get_component(0,2)
                   + get_component(2,0)*get_component(0,1)*get_component(1,2)
                   - get_component(0,2)*get_component(1,1)*get_component(2,0)
                   - get_component(0,1)*get_component(1,0)*get_component(2,2)
                   - get_component(0,0)*get_component(1,2)*get_component(2,1);
    }
    else {
        det = 0;
        for( int i=0; i<dimension; i++ ) {
            Real_matrix sub_matrix( dimension - 1 );
            det += get_component( i, 0 )*sub_matrix.determinant();
        }
    }
    return det;
}

void Real_matrix::inverse() {
    Real_matrix inv(dimension);
    double det = determinant();
    for( int i=0; i<dimension; i++ ) {
        for( int j=0; j<dimension; j++ ) {
            Real_matrix sub_matrix(dimension - 1);
            sub_matrix = get_submatrix( i, j );
            double element = sub_matrix.determinant() / det;
            inv.set_component( i, j, element );
        }
    }
}

Array_double Real_matrix::multiply_right_by_array_double( Array_double &vector ) {
    int dim = vector.get_dimension();
    Array_double result(dim);
    for( int i=0; i<dim; i++ ) {
        double tmp = 0;
        for( int j=0; j<dim; j++ ) {
            tmp += vector.get_component(j)*get_component(i,j);
        }
        result.set_component(i, tmp);
    }
    return result;
}

Array_double Real_matrix::multiply_left_by_array_double( Array_double &vector ) {
    int dim = vector.get_dimension();
    Array_double result(dim);
    for( int i=0; i<3; i++ ) {
        double tmp = 0;
        for( int j=0; j<dim; j++ ) {
            tmp += vector.get_component(j)*get_component(j,i);
        }
        result.set_component(i, tmp);
    }
    return result;
}



// Private library
//-----------------------------------
Real_matrix Real_matrix::get_submatrix( int i, int j ) {
    Real_matrix sub_matrix( dimension - 1 );
    int p=0;
    int q=0;
    for( int n=0; n<dimension; n++ ) {
        for( int k=0; k<dimension; k++ ) {
            if( i!=n && j!=k ) {
                double element = get_component( n, k );
                sub_matrix.set_component( p, q, element );
            }
            q += 1;
        }
        q = 0;
        p += 1;
    }
    return sub_matrix;
}

