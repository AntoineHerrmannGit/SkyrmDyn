#ifndef REAL_MATRIX_H
#define REAL_MATRIX_H

#include "Maths/Objects/Array/Array_double/array_double.h"

#include <vector>

class Real_matrix
{
public:
    // Constructor
    //-----------------------------------
    Real_matrix( int dimension );

    // Gettters
    //-----------------------------------
    std::vector< std::vector< double > > get_matrix();
    double get_component( int i, int j );
    int get_dimension();

    // Settters
    //-----------------------------------
    void set_component( int i, int j, double &element );

    // Public libraries
    //-----------------------------------
    void transpose();
    double determinant();
    void inverse();

    Array_double multiply_right_by_array_double( Array_double &vector );
    Array_double multiply_left_by_array_double( Array_double &vector );

private:
    std::vector< std::vector< double > > matrix;
    int dimension = 0;

    Real_matrix get_submatrix( int i, int j );
};

#endif // REAL_MATRIX_H
