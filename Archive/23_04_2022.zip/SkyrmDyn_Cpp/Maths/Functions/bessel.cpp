#include "bessel.h"

#include "special.h"
#include "Constants/constants.h"

#include <math.h>

double BesselJ( int n, double x ) {
    double j = 0;
    for( int k=0; k<=1000; k++ ){
        j += pow( -1, k ) * pow( (0.5 * x), (2*k) ) / ( factorial(k) * factorial(n + k) );
    }
    return pow( (0.5 * x), 2) * j;
}

double BesselY( int n, double x ) {
    double first_term = 0;
    float step = 0.001;
    float t = 0;
    while( t<pi ) {
        first_term += sin( x * sin(t) - n * t );
        t += step;
    }

    double second_term = 0;
    t = 0;
    while( t<pi ) {
        second_term += ( exp( n*t ) + pow( -1,n ) * exp( -n*t ) ) * exp( -x*sinh( t ) );
        t += step;
    }
    return ( first_term - second_term ) / pi;
}
