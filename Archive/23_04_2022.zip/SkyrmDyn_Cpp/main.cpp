#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>

#include <typeinfo>

#include <filesystem>

#include <ctime>
#include <random>
#include <chrono>

#include "Objects/Lattice/lattice.h"
#include "File_management/file_management.h"


int main( /* int argc, char *argv[] */ )
{
    try {
        clear_directory( "Positions" );
        clear_directory( "Spins" );
        Lattice lattice;
        std::cout << "Well done \n";
    }
    catch( std::string str ) {
        std::cout << str << "\n";
    }
    return 0;
}
