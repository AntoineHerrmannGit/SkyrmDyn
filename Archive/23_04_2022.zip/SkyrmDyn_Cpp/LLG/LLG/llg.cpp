#include "llg.h"

#include "Maths/Objects/Array/Array_double/array_double.h"
#include "Maths/Objects/Matrix/Real_matrix/real_matrix.h"

#include "Maths/Operators/vector_operators.h"
#include "Maths/Objects/Tensor/Vector_tensor/vector_tensors.h"

#include "Constants/constants.h"

void euler_llg( Array_double &spin, Array_double &magnetic_field ) {
    // grab constants
    double gamma = e / (2*m_e);
    double damping = 1;
    // double damping = grab_parameter( "damping" );
    double llg_time = 1000;
    // double llg_time = grab_parameter( "llg_time_step" );
    double llg_time_step = 0.001;
    // double llg_time_step = grab_parameter( "llg_time_step" );

    double time = 0;
    while( time<llg_time ) {
        euler_llg_step( spin, magnetic_field, llg_time_step, gamma, damping );
        time += llg_time_step;
    }
}

void euler_llg_step( Array_double &spin, Array_double &magnetic_field, double llg_time_step, double &gamma, double damping ) {
    Real_matrix coupling_matrix(3);
    build_coupling_matrix( coupling_matrix, spin, llg_time_step, damping );

    Array_double second_term( 3 );
    build_second_term( second_term, spin, magnetic_field, gamma );
    coupling_matrix.inverse();

    Array_double evolution( 3 );
    evolution = coupling_matrix.multiply_right_by_array_double( second_term );

    spin.add( evolution );
    spin.normalize();
}

void build_coupling_matrix( Real_matrix &coupling_matrix, Array_double &spin, double llg_time_step, double damping ) {
    for( int i=0; i<3; i++ ) {
        for( int j=0; j<3; j++ ) {
            double element = 0;
            if( i==j ) {
                element = 1;
            }
            else {
                int k = Levi_Civita_get_k( i, j );
                element = llg_time_step * damping * Levi_Civita( i, j, k ) * spin.get_component(k);
            }
            coupling_matrix.set_component( i, j, element );
        }
    }
}

void build_second_term( Array_double &second_term, Array_double &spin, Array_double &magnetic_field, double &gamma ) {
    second_term = cross( spin, magnetic_field );
    second_term.multiply_by_scalar( gamma );
}









