#ifndef LLG_H
#define LLG_H

#include "Maths/Objects/Array/Array_double/array_double.h"
#include "Maths/Objects/Matrix/Real_matrix/real_matrix.h"

void euler_llg( Array_double &spin, Array_double &magnetic_field );

void euler_llg_step( Array_double &spin, Array_double &magnetic_field, double llg_time_step, double &gamma, double damping );

void build_coupling_matrix( Real_matrix &coupling_matrix, Array_double &spin, double llg_time_step, double damping );

void build_second_term( Array_double &second_term, Array_double &spin, Array_double &magnetic_spin, double &gamma );


#endif // LLG_H
