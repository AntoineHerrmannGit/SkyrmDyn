#include "Error_messages/error_messages.h"

#include <filesystem>

std::string generate_assignation_error_message( std::string variable ) {
    std::string message = " ";//location_of_error();
    message += " : assignation of " + variable + " failed. \n";
    return message;
}
std::string generate_unfound_error_message( std::string variable ) {
    std::string message = location_of_error();
    message += " : variable " + variable + " not found. \n";
    return message;
}
std::string generate_declaration_error_message( std::string variable ) {
    std::string message = location_of_error();
    message += " : " + variable + " not declared. \n";
    return message;
}

std::string location_of_error() {
    std::string message = "Error in : ";
    std::filesystem::path path = std::filesystem::current_path();
    std::string path_name = path.string();

//    bool found = true;
//    while( found ) {
//        if( path_name.find( "SkyrmDyn" ) != std::string::npos ) {
//            path_name = path_name.substr( path_name.find( "SkyrmDyn" ) );
//        }
//        else {
//            found = false;
//        }
//    }
//    message += path_name + " : " + __FUNCTION__;
//    message += __FILE__;
//    message += "   ";
//    message += __FUNCTION__;
    return message;
}
