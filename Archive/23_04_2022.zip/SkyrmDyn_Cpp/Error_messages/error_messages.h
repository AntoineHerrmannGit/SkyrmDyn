#ifndef ERROR_MESSAGES_H
#define ERROR_MESSAGES_H

#include <string>

#define AssignationError( var ) ( std::string("Error in ") + __FILE__ + "  :  " + __FUNCTION__ + std::string("  : assignation of ") + std::string( var ) + std::string(" failed.") )

#define DeclarationError( var ) ( std::string("Error in ") + __FILE__ + "  :  " + __FUNCTION__ + std::string("  : declaration of ") + std::string( var ) + std::string(" failed.") )

#define UnfoudVariableError( var ) ( std::string("Error in ") + __FILE__ + "  :  " + __FUNCTION__ + std::string("  :  ") + std::string( var ) + std::string(" not found.") )


#endif // ERROR_MESSAGES_H
