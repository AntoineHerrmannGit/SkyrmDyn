#include "Objects/Lattice/lattice.h"

double Lattice::total_topological_charge() {

}
