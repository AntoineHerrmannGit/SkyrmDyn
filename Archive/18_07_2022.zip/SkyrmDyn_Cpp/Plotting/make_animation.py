import numpy as np
from matplotlib import pyplot as plt
from matplotlib import animation as ani
from mpl_toolkits.mplot3d import Axes3D
import os

def Animate_magnetization():
    
    file = open( os.path.join( "..\..\Outputs\Magnetization\magnetization.dat" ), "r" )
    
    time = []
    mx = []
    my = []
    mz = []
    
    for row in file :
        row = row.split( "   " )
        time.append( float( row[0] ) )
        mx.append( float( row[1] ) )
        my.append( float( row[2] ) )
        mz.append( float( row[3] ) )
    
    file.close()
    
    dataSet = np.array([ mx, my, mz ])
    numDataPoints = len( time )
    
    fig = plt.figure()
    ax = Axes3D(fig)
    
    line = plt.plot(dataSet[0], dataSet[1], dataSet[2], lw=2, color='red')[0]
    
    def func(num, dataSet, line):
        line.set_data(dataSet[0:2, :num])    
        line.set_3d_properties(dataSet[2, :num])    
        return line
    
    
    ax.set_xlim( -1, 1 ) 
    ax.set_ylim( -1, 1 ) 
    ax.set_zlim( -1, 1 ) 
    
    ax.set_xlabel("Mx ( a.u. )")
    ax.set_ylabel("My ( a.u. )")
    ax.set_zlabel("Mz ( a.u. )")
    
    movie = ani.FuncAnimation(fig, func, frames=numDataPoints, fargs=(dataSet,line), interval=1, blit=False)
    
    movie.save( 'magnetization.gif' )
    
if __name__ == "__main__":
    
    Animate_magnetization()