
#define CATCH_CONFIG_MAIN
#include <tests/catch.hpp>
