#include "Objects/System_config/system_config.h"

#include <string>

void System_config::make_graphs() {
    std::string graph_cmd = " \\\" \\\"" + python + "\" \\\"" + code + "SkyrmDyn_Cpp\\Plotting\\make_graphs.py\\\" \\\" \"";
    std::system( graph_cmd.c_str() );
    std::system( std::string( "MOVE .\\energy* .\\Outputs\\Energy\\" ).c_str() );
    std::system( std::string( "MOVE .\\magnetization* .\\Outputs\\Magnetization\\" ).c_str() );
    std::system( std::string( "MOVE .\\magnetization_3D* .\\Outputs\\Magnetization\\" ).c_str() );
}




