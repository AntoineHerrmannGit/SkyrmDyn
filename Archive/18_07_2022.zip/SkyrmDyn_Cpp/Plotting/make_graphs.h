#ifndef MAKE_GRAPHS_H
#define MAKE_GRAPHS_H

#include "Objects/System_config/system_config.h"

void make_graphs( System_config syst );
void make_images( System_config syst );


#endif // MAKE_GRAPHS_H
