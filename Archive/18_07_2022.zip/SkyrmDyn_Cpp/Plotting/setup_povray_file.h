#ifndef SETUP_POVRAY_FILE_H
#define SETUP_POVRAY_FILE_H

#include <string>

void setup_povray_file();

void move_pov_and_include_spin_file( std::string filename );

void set_camera();
void set_light_source();

void write_nb_povray_files();

#endif // SETUP_POVRAY_FILE_H
