#include "Objects/Lattice/lattice.h"

#include "Error_messages/error_messages.h"

#include "Objects/Lattice/Boundary_conditions/boundary_conditions.h"

#include <vector>
#include <string>

void Lattice::setup_neighbors() {
    // Setup the nearest neighbors of each atom
    attribute_nearest_neighbors();

    // Setup the neighbors list for each atom
    for( Cell& cells : lattice ) {
        std::vector < Atom >& current_cell = cells.get_cell();
        for( Atom& atoms : current_cell ) {
            // Zeroth rank neighbor is the atom itself
            std::vector< Atom* > tmp_list;
            tmp_list.push_back( &atoms );
            atoms.get_neighbors_list().push_back( tmp_list );

            // Find the neighbors from order of links that
            // relates the atom to the atom of reference

            // For all ranks, until all atoms are considered
            int counter = 1;
            int neighbor_rank = 0;
            while( counter < nb_atoms ) {
                // Consider the last crown of neighbors
                std::vector< Atom* > new_tmp_list;
                for( Atom* atom : atoms.get_neighbors( neighbor_rank ) ) {
                    // Gather all possible candidates
                    for( Atom* neighboring_atom : atom->get_nearest_neighbors() ) {
                        new_tmp_list.push_back( neighboring_atom );
                    }
                }

                // Get all already referenced atoms
                // in the deeper crowns of neighbors
                std::vector< Atom* > referenced_neighbors;
                int min_rank = std::max( 0, neighbor_rank - 1 );
                for( int i=min_rank; i<=neighbor_rank; i++ ) {
                    for( Atom* referenced_atom : atoms.get_neighbors( i ) ) {
                        referenced_neighbors.push_back( referenced_atom );
                    }
                }

                // Compare the two lists and put all atoms
                // NOT in common in a new list
                std::vector< Atom* > new_neighbors;
                for( Atom* atom : new_tmp_list ) {
                    for( Atom* candidate : referenced_neighbors ) {
                        if( atom != candidate ) {
                            new_neighbors.push_back( atom );
                        }
                    }
                }

                // Reference the new atoms
                neighbor_rank ++;
                atoms.set_neighbor( new_neighbors );
                counter += (int) new_neighbors.size();
            }
        }
    }
}

void Lattice::setup_nearest_neighbors( Atom& atom ) {
    Cell& cell = *atom.get_mother_cell();
    std::vector< Cell* > neighboring_cells = find_neighboring_cells( cell );
    std::vector< Atom* > neighbors_list;
    for( Cell* cells : neighboring_cells ) {
        std::vector < Atom >& current_cell = cells->get_cell();
        for( Atom& atoms : current_cell ) {
            if( parameters.get_bounday_conditions() == "none" ) {
                if( atom.distance( atoms ) <= parameters.get_lattice_step_sigma() * parameters.get_lattice_step() ) {
                    neighbors_list.push_back( &atoms );
                }
            }
            else if( parameters.get_bounday_conditions() == "tor" ) {

            }
            else if( parameters.get_bounday_conditions() == "sphere" ) {

            }
            else if( parameters.get_bounday_conditions() == "linear" ) {

            }
            else {
                throw( AssignationError( "boundary condition" ) );
            }
        }
    }
    atom.set_nearest_neighbors( neighbors_list );
}

void Lattice::attribute_nearest_neighbors() {
    std::vector< Atom* > neighbors_list;
    for( Cell& cells : lattice ) {
        for( Atom& atoms : cells.get_cell() ) {
            setup_nearest_neighbors( atoms );
        }
    }
}





